# spam_AI
A software project based on detecting spam mails, SMS and calls .
Used Naive Bayes 

